<?php 
    $email = "";
    $password = "";

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YKOM - Zaloguj się!</title>
    <link rel="stylesheet" href="css\logujstyle.css">
</head>
<body>
    <header>
        <a href="index.php"><h1>Y-KOM - Twoj sklep komputerowy!</h1></a>
    </header>


    <main>
        <div class="logowaniemain">
            <h2>Zaloguj się!</h2><br>
        <form method="POST" action="loguj.php">
            <label>Email: </label><br>
            <input type="text" name="email"><br><br>
            <label>Hasło: </label><br>
            <input type="password" name="password"><br><br>
            <button type="submit" id="logowaniebutton">Zaloguj</button>
        </form><br>
        <?php
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $conn = mysqli_connect("localhost", "root", "", "ykom_baza");
    
            $email = $_POST['email'];
            $password = $_POST['password'];

            $q1 = 'SELECT dane_uzyt_zam.email, dane_uzyt_zam.haslo FROM dane_uzyt_zam WHERE email LIKE "' . $email . '"';
            $r1 = mysqli_query($conn, $q1);
            $row = mysqli_fetch_array($r1);


            if(isset($row)) {
                if ($row[0] == "") {
                    echo "Nie znaleziono takiego adresu email";
                }
                else if (sha1($password) != $row[1]) {
                    echo "Podano bledne haslo!";
                }
                else {
                    echo "Zalogowano pomyslnie!";
                }
            } else {
                echo "Nie znaleziono takiego adresu email";
            }
        }
        
        ?>
        <p>Masz problemy z logowaniem?</p>
        <a href="">Zresetuj hasło</a>
        <br><br>
        <p>Nie posiadasz jeszcze konta?
        </p>
        <a href="rejestracja.php">Załóż konto</a>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
    </main>
           
<footer>
        <div id="orderSec">
            <h3>Zamówienia</h3>
            <a href="">Dostawa i płatności</a>
        </div>
        <div id="salesSec">
            <h3>Promocje</h3>
            <a href="">Wyprzedaż</a>
        </div>
        <div id="aboutSec">
            <h3>y-kom</h3>
            <a href="">O nas!</a>
        </div>
        <div id="contactSec">
            <h3>Kontakt</h3>
            <img src="img/phone.png"/><p> +48 123 456 789</p>
        </div>
    </footer>


    
</body>
</html>